# Security Policy

## Supported Versions

Versions currently being supported with security updates:

| Version | Supported          |
| ------- | ------------------ |
| 3.8.x   | :white_check_mark: |
| < 3.8.x | :x:                |
| 3.9.x   | :white_check_mark: |

## Reporting a Vulnerability

If you found a vulnerability send it to security@nagstamon.de.
