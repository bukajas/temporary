Contribution
============

Of course every contribution is welcome - without contributors Nagstamon never would have been what it is today.

- Some basic information is already available at https://nagstamon.de/documentation.

- The Python packages required to run Nagstamon are listed in https://github.com/HenriWahl/Nagstamon/blob/master/requirements.txt.

- Building a binary release is easily done by running https://github.com/HenriWahl/Nagstamon/blob/master/build/build.py
