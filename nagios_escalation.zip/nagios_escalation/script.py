#!/usr/bin/env python3
import requests
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
from Objects import (GenericService, GenericHost,Result)
import logging
import os
import argparse


# Configure logging
logging.basicConfig(
    filename='/home/asszonyij/Epofis/nagios_escalation/mylog.log',  # Specify the log file name
    level=logging.DEBUG,  # Set the logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    format='%(asctime)s-%(levelname)s-%(message)s'
)

# ['name', -service name
# 'status',  - critical
# 'status_information',  - (service check timed out)
#  'status_type', -hard/soft (not implemented)
# 'last_check', - time of last check
# 'duration', - how long
# 'attempt',
# 'passiveonly', 
# 'acknowledged', 
#  'notifications_disabled', 
# 'flapping', 
# 'scheduled_downtime',
#  'visible', 
#  'server', 
#   'host',
#  'service', 
#   'unreachable', 



#TODO
# SMS and call notifications, posilat to vsem, prozatim DONE
# name and password be arguments, and so the receiver of sms DONE
# failproof
# Input logging, into parsing part, and deleting part.





def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-tel", "--telephone", help="Telephone number(s) separated by comma")
    parser.add_argument("-pw", "--password", help="Password")
    parser.add_argument("-url", "--url", help="URL address")
    args = parser.parse_args()
    
    # telephone_numbers = args.telephone.split(',')
    # print(telephone_numbers)
    # Nagios_url = args.url
    # password = args.password





    formatted_numbers = []
    for number in telephone_numbers:
        number = number.lstrip('+')
        if not number.startswith('420'):
            number = '420' + number
        if len(number) == 12:
            number = '+' + number
            formatted_numbers.append(number)
        else:
            print(f"Invalid number: {number}")
    
    print("Telephone: ", formatted_numbers)
    print("Password: ", args.password)
    print("URL: ", args.url)
    
    HARD_url = Nagios_url+'/cgi-bin/nagios3/status.cgi?host=all&servicestatustypes=253&serviceprops=262144&limit=0'
    SOFT_url = Nagios_url+'/cgi-bin/nagios3/status.cgi?host=all&servicestatustypes=253&serviceprops=524288&limit=0'    
    USER_AGENT = '{0}/{1}/{2}'.format("test", "1.2.3", "Linux")
    timeout=10
    HARD_nagitems = {'services': [], 'hosts': []}
    SOFT_nagitems = {'services': [], 'hosts': []}
    
    HARD_new_hosts = dict()
    SOFT_new_hosts = dict()
    typ = 'obj'
    current_time = datetime.now()
    STATUS_MAPPING = {'ack.gif': 'acknowledged',
                        'passiveonly.gif': 'passiveonly',
                        'disabled.gif': 'passiveonly',
                        'ndisabled.gif': 'notifications_disabled',
                        'downtime.gif': 'scheduled_downtime',
                        'flapping.gif': 'flapping'}
    #fetch data from nagios server
    
    HARD_result = fetchData(username,password,USER_AGENT,HARD_nagios_uri,timeout,typ)
    HARD_formated_result = formatData(HARD_result,HARD_nagitems,STATUS_MAPPING,HARD_new_hosts)
    
    SOFT_result = fetchData(username,password,USER_AGENT,SOFT_nagios_uri,timeout,typ)
    SOFT_formated_result = formatData(SOFT_result,SOFT_nagitems,STATUS_MAPPING,SOFT_new_hosts)
    
    #get data saved in scripts cache
    changed = False
    cache_list, cache_server_list, cache_service_list, changed = read_cache()
    cache_combined = [f"{x};{y}" for x,y in zip(cache_server_list,cache_service_list)]
    
    current_list = []
    SOFT_current_list=[]
    
    for host in SOFT_formated_result.values(): 
        for service in host.services.values(): 
            SOFT_current_list.append(f"{service.host};{service.name}")
    
    #create temporary list of current services
    for host in HARD_formated_result.values(): 
        for service in host.services.values(): 
            current_list.append(f"{service.host};{service.name}")

    for host in HARD_formated_result.values(): 
        for service in host.services.values():         
            index = -1 
            exists = False
            for idx,servr in enumerate(cache_server_list):
                if servr == service.host:
                    index = idx
                if index != -1 and cache_service_list[index] == service.name:
                    exists = True
                    logging.info(f"{servr};{cache_service_list[index]} > Existing Error (Error information: {service.status_information})")
                    logging.info(f"{servr};{cache_service_list[index]} > flapping:{service.flapping};notification_disabled:{service.notifications_disabled};scheduled_downtime:{service.scheduled_downtime};acknowledged:{service.acknowledged}")
                    break
                broke = False
                for i in SOFT_current_list:
                    if i in cache_combined:
                        
                        nam = i.split(";")[0]
                        namm = i.split(";")[1]
                        service = SOFT_formated_result[nam].services[namm]
                        print("in SOFT STATE")
                        ind = cache_combined.index(i)
                        valu = SOFT_formated_result[nam].services[namm]
                        exists = True
                        logging.info(f"{servr};{cache_service_list[ind]} > Existing Error (Error information: {valu.status_information})")
                        logging.info(f"{servr};{cache_service_list[ind]} > flapping:{valu.flapping};notification_disabled:{valu.notifications_disabled};scheduled_downtime:{valu.scheduled_downtime};acknowledged:{valu.acknowledged}")
                        broke = True
                        break
                if broke:
                    break    
                    
                
            else:
                print("New error")
                logging.info(f"New Error> {service.host};{service.name},last_check:{service.last_check},notification_disabled:{service.notifications_disabled},scheduled_downtime:{service.scheduled_downtime},acknowledged:{service.acknowledged},status:{service.status},status_information:{service.status_information}")
                new_entry = add_to_cache(service)
                cache_list.append(new_entry)
                index = len(cache_list)-1
                cache_server_list.append(new_entry['service_server'])
                cache_service_list.append(new_entry['service_name'])
                exists = True
                changed = True

            if exists:
                last_not = cache_list[index]["service_last_notification_date"]
                time_diference = abs(current_time - cache_list[index]["service_last_notification_date"])
                bol = time_diference > timedelta(hours=1)
                logging.info(f"{service.host};{service.name} > time from last notification: {time_diference}")
                # check if its more than hour but also if notificatio disable or acknowledged
                if bol:
                    # if service.notifications_disabled or service.scheduled_downtime:
                    if service.acknowledged or service.notifications_disabled or service.scheduled_downtime:
                        logging.info(f"{service.host};{service.name} > Time difference more than 1 hour but acknowledged")
                        logging.info(f"{service.host};{service.name} > SMS not send - service error known")    
                    else:
                        logging.info(f"{service.host};{service.name} > Time difference more than 1 hour")
                        logging.info(f"{service.host};{service.name} > Sending SMS to {formatted_numbers}")
                        
                        #send notification
                        print("send SMS")
                        send_notification(service,formatted_numbers)
                        
                        cache_list[index]["service_last_notification_date"] = current_time
                        logging.info(f"{service.host};{service.name} > Last notification date changed from {last_not} to {current_time}")
                        changed = True
            else:
                print("Not in cache, will be deleted ")
                       
    
    # check if any errors are there anymore
    temp_combined = cache_combined.copy()
    for index,cached_servers in enumerate(cache_combined):
        if cached_servers in current_list or cached_servers in SOFT_current_list:
            pass
        else:
            #delete
            index_to_delete = temp_combined.index(cached_servers)
            service_host= cache_list[index_to_delete]['service_server']
            service_name= cache_list[index_to_delete]['service_name']
            logging.info(f"{service_host};{service_name} > Removing from cache, Error not exists or solved")
            cache_list.pop(index_to_delete)      
            temp_combined.pop(index_to_delete)
            changed=True
    
    #if changed then save it so cache  
    if changed:
        edit_cache(cache_list)              
             


def send_notification(service,formatted_numbers):
    current = datetime.now()
    admins = formatted_numbers
    logging.info(f"{service.host};{service.name} > SMS notification send to {admins}")

    for i in admins:
        # calling
        CALL_cmd = f'/usr/bin/sudo /etc/nagios3/call_gw.php {i}'
        print(CALL_cmd)
        # os.system(CALL_cmd)
        
        # SMS
        SMS_cmd = f'/usr/bin/sudo -u nagios /etc/nagios3/tel_gw.sh -n {i} -s "{current} ESCALATION: {service.host}/{service.name}"'
        # os.system(SMS_cmd)
        logging.info(f"{service.host};{service.name} > SMS and call made to {i}")
        pass


     
def read_cache():
    ack,notif,flap,down,unreach,visib = False,False,False,False,False,False
    unique_pair = set()
    changed = False
    temp_list = []
    temp_server_list = []
    temp_services_list = []
    with open("/home/asszonyij/Epofis/nagios_escalation/cache.txt", "r") as file:
        lines = file.readlines()

        for i in lines:
            try:
                i = i.strip()
                values = i.split(";")
                if len(values) < 11:
                    changed = True
                    continue
                if values[3] == "False":
                    ack = False
                ack = True if values[3].lower() == 'true' else False
                notif = True if values[4].lower() == 'true' else False
                down = True if values[5].lower() == 'true' else False
                flap = True if values[6].lower() == 'true' else False 
                
                unreach = True if values[9].lower() == 'true' else False 
                visib = True if values[10].lower() == 'true' else False 
                temp_dict = {
                    'service_server': values[0],
                    'service_name': values[1],
                    'status_change_date': datetime.strptime(values[2], '%Y-%m-%d %H:%M:%S.%f'),
                    'service_acknowledged': ack,
                    'service_notifications_disabled': notif,
                    'service_scheduled_downtime': down,
                    'service_flapping': flap,
                    'service_last_notification_date': datetime.strptime(values[7], '%Y-%m-%d %H:%M:%S.%f'),
                    'service_status': values[8],
                    'service_unreachable': unreach,
                    'service_visible': visib
                }
                temp_list.append(temp_dict)
                temp_server_list.append(temp_dict["service_server"])
                temp_services_list.append(temp_dict["service_name"])
            except IndexError:
                continue
            
    file.close()
    return temp_list, temp_server_list, temp_services_list, changed



#adds a new non-OK service to cache
def add_to_cache(service,):
    current = datetime.now()
    new_entry = {'service_server': service.host,
                 'service_name': service.name,
                 'service_change_date': service.status_change_date,
                 'service_acknowledge': service.acknowledged,
                 'service_notifications_disabled': service.notifications_disabled,
                 'service_scheduled_downtime': service.scheduled_downtime,
                 'service_flapping': service.flapping,
                 'service_last_notification_date': service.status_change_date,
                 'service_status': service.status,
                 'service_unreachable': service.unreachable,
                 'service_visible': service.visible
                 }
    return new_entry

def edit_cache(cache_list):
    #something changed
    with open("/home/asszonyij/Epofis/nagios_escalation/cache.txt", "w") as file:
        for i in cache_list:
            values_str = ';'.join(str(value) for value in i.values())
            file.write(values_str)
            file.write("\n")


def get_start_date(duration):
    time_list = [int(i[:-1]) for i in duration.split()]
    delta = timedelta(days=time_list[0], hours=time_list[1], minutes=time_list[2], seconds=time_list[3])
    current = datetime.now()
    start_date = current - delta
    return start_date

class Result(object):
    result = ''
    error = ''
    status_code = 0

    def __init__(self, **kwds):
        for k in kwds:
            self.__dict__[k] = kwds[k]

def not_empty(x):
    return bool(x.replace('&nbsp;', '').strip())

def fetchData(username,password,USER_AGENT,nagios_uri,timeout,typ):
    
    logging.info(f"Data fetched from {nagios_uri}")

    session = requests.Session()
    session.headers['User-Agent'] = USER_AGENT
    session.auth = requests.auth.HTTPBasicAuth(username, password)
    response = session.get(nagios_uri, timeout=timeout)
    # response = session.post(nagios_uri, data=cgi_data, timeout=timeout)
    PARSER = 'lxml'
    if typ == 'obj':
        yummysoup = BeautifulSoup(response.text, PARSER)
        test =  Result(result=yummysoup, status_code=response.status_code)   
        
    elif typ == 'raw':
        test = Result(result=response.text,  status_code=response.status_code)
        
    elif typ == 'xml':
        xmlobj = BeautifulSoup(response.text, PARSER)
        test = Result(result=xmlobj, status_code=response.status_code)
        
    return test


def formatData(result,nagitems,STATUS_MAPPING,new_hosts):
    htobj, error, status_code = result.result, result.error, result.status_code
    table = htobj('table', {'class': 'status'})[0]
    if len(table('tbody')) == 0:
        trs = table('tr', recursive=False)
    else:
        tbody = table('tbody')[0]
        trs = tbody('tr', recursive=False)
    trs.pop(0)
    tds = []
    #HOSTS
    for tr in trs:
        try:
            # ignore empty <tr> rows
            if len(tr('td', recursive=False)) > 1:
                n = dict()
                # get tds in one tr
                tds = tr('td', recursive=False)
                # host
                try:
                    n['host'] = str(tds[0].table.tr.td.table.tr.td.a.text)
                except Exception:
                    n['host'] = str(nagitems[len(nagitems) - 1]['host'])
                # status
                n['status'] = str(tds[1].text)
                # last_check
                n['last_check'] = str(tds[2].text)
                # duration
                n['duration'] = str(tds[3].text)
                if len(tds) < 7:
                    # the old Nagios table
                    # status_information
                    if len(tds[4](text=not_empty)) == 0:
                        n['status_information'] = ''
                    else:
                        n['status_information'] = str(tds[4].text).replace('\n', ' ').replace('\t', ' ').strip()
                    n['attempt'] = 'n/a'
                else:
                    n['attempt'] = str(tds[4].text).strip()
                    # status_information
                    if len(tds[5](text=not_empty)) == 0:
                        n['status_information'] = ''
                    else:
                        n['status_information'] = str(tds[5].text).replace('\n', ' ').replace('\t', ' ').strip()
                # status flags
                n['passiveonly'] = False
                n['notifications_disabled'] = False
                n['flapping'] = False
                n['acknowledged'] = False
                n['scheduled_downtime'] = False

                # map status icons to status flags
                icons = tds[0].findAll('img')
                for i in icons:
                    icon = i['src'].split('/')[-1]
                    if icon in STATUS_MAPPING:
                        n[STATUS_MAPPING[icon]] = True
                # cleaning
                del icons

                # add dictionary full of information about this host item to nagitems
                nagitems['hosts'].append(n)
                # after collection data in nagitems create objects from its informations
                # host objects contain service objects
                if n['host'] not in new_hosts:
                    new_host = n['host']
                    new_hosts[new_host] = GenericHost()
                    new_hosts[new_host].name = n['host']
                    new_hosts[new_host].server = n['host']
                    new_hosts[new_host].status = n['status']
                    new_hosts[new_host].last_check = n['last_check']
                    new_hosts[new_host].duration = n['duration']
                    new_hosts[new_host].attempt = n['attempt']
                    new_hosts[new_host].status_information = n['status_information']
                    new_hosts[new_host].passiveonly = n['passiveonly']
                    new_hosts[new_host].notifications_disabled = n['notifications_disabled']
                    new_hosts[new_host].flapping = n['flapping']
                    new_hosts[new_host].acknowledged = n['acknowledged']
                    new_hosts[new_host].scheduled_downtime = n['scheduled_downtime']
                    new_hosts[new_host].status_type = "hard/soft"

                    
                del tds, n
        except Exception:
            print("Parsing miskate, no problem")
            
    #SERVICES
    for tr in trs:
        try:
            # ignore empty <tr> rows - there are a lot of them - a Nagios bug?
            tds = tr('td', recursive=False)
            if len(tds) > 1:
                n = dict()
                # host
                # the resulting table of Nagios status.cgi table omits the
                # hostname of a failing service if there are more than one
                # so if the hostname is empty the nagios status item should get
                # its hostname from the previuos item - one reason to keep 'nagitems'
                try:
                    n['host'] = str(tds[0](text=not_empty)[0])
                except Exception:
                    n['host'] = str(nagitems['services'][len(nagitems['services']) - 1]['host'])
                # service
                n['service'] = str(tds[1](text=not_empty)[0])
                # status
                n['status'] = str(tds[2](text=not_empty)[0])
                # last_check
                n['last_check'] = str(tds[3](text=not_empty)[0])
                # duration
                n['duration'] = str(tds[4](text=not_empty)[0])
                # attempt
                # to fix http://sourceforge.net/tracker/?func=detail&atid=1101370&aid=3280961&group_id=236865 .attempt needs
                # to be stripped
                n['attempt'] = str(tds[5](text=not_empty)[0]).strip()
                # status_information
                if len(tds[6](text=not_empty)) == 0:
                    n['status_information'] = ''
                else:
                    n['status_information'] = str(tds[6].text).replace('\n', ' ').replace('\t', ' ').strip()
                # status flags
                n['passiveonly'] = False
                n['notifications_disabled'] = False
                n['flapping'] = False
                n['acknowledged'] = False
                n['scheduled_downtime'] = False

                # map status icons to status flags
                icons = tds[1].findAll('img')
                for i in icons:
                    icon = i['src'].split('/')[-1]
                    if icon in STATUS_MAPPING:
                        n[STATUS_MAPPING[icon]] = True
                # cleaning
                del icons

                # add dictionary full of information about this service item to nagitems - only if service
                nagitems['services'].append(n)
                # after collection data in nagitems create objects of its informations
                # host objects contain service objects
                if n['host'] not in new_hosts:
                    new_hosts[n['host']] = GenericHost()
                    new_hosts[n['host']].name = n['host']
                    new_hosts[n['host']].status = 'UP'
                    # trying to fix https://sourceforge.net/tracker/index.php?func=detail&aid=3299790&group_id=236865&atid=1101370
                    # if host is not down but in downtime or any other flag this should be evaluated too
                    # map status icons to status flags
                    icons = tds[0].findAll('img')
                    for i in icons:
                        icon = i['src'].split('/')[-1]
                        if icon in STATUS_MAPPING:
                            new_hosts[n['host']].__dict__[STATUS_MAPPING[icon]] = True

                # if a service does not exist create its object
                if n['service'] not in new_hosts[n['host']].services:
                    new_service = n['service']
                    new_hosts[n['host']].services[new_service] = GenericService()
                    new_hosts[n['host']].services[new_service].host = n['host']
                    new_hosts[n['host']].services[new_service].name = n['service']
                    new_hosts[n['host']].services[new_service].server = n['host']
                    new_hosts[n['host']].services[new_service].status = n['status']
                    new_hosts[n['host']].services[new_service].last_check = n['last_check']
                    new_hosts[n['host']].services[new_service].duration = n['duration']
                    new_hosts[n['host']].services[new_service].attempt = n['attempt']
                    new_hosts[n['host']].services[new_service].status_information = n['status_information']
                    new_hosts[n['host']].services[new_service].passiveonly = n['passiveonly']
                    new_hosts[n['host']].services[new_service].notifications_disabled = n[
                        'notifications_disabled']
                    new_hosts[n['host']].services[new_service].flapping = n['flapping']
                    new_hosts[n['host']].services[new_service].acknowledged = n['acknowledged']
                    new_hosts[n['host']].services[new_service].scheduled_downtime = n['scheduled_downtime']
                    new_hosts[n['host']].services[new_service].status_type = "hard/soft"
                    new_hosts[n['host']].services[new_service].status_change_date = get_start_date(n['duration'])
                del tds, n
        except Exception:
            print("Heeror")
    # do some cleanup
    htobj.decompose()
    del htobj, trs, table    
    
    return new_hosts  
        

    

    
   
    


if __name__ == "__main__":
    logging.info("Starting a script")
    main()
    logging.info("Ending script")